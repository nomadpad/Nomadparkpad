const menuButton = document.querySelector('.menu-button');
const navLinks = document.querySelector('.nav-links');

menuButton?.addEventListener('click', () => {
  navLinks.classList.toggle('open');
});

document.querySelectorAll('.nav-links a').forEach((link) => {
  link.addEventListener('click', () => navLinks.classList.remove('open'));
});

function handleForm(event) {
  event.preventDefault();
  const form = event.target;
  const note = document.getElementById('formNote');
  const data = new FormData(form);
  const role = data.get('role');
  note.textContent = `Thanks! You are on the early list as: ${role}. Next step is connecting this form to email or a database.`;
  form.reset();
}
